const projects = [
  {
    title: "Cadence SCM",
    description: "Predictive packaging and supply chain tool tailored to cannabis businesses."
  },
  {
    title: "eBay Estimator",
    description: "Keyword-to-price prediction engine using OpenAI + eBay API."
  }
];

export default projects;